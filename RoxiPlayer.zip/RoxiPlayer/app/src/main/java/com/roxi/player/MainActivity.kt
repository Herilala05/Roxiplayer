package com.roxi.player

import android.graphics.Color
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import com.roxi.player.ui.RoxiApp
import com.roxi.player.ui.theme.RoxiTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge(
            statusBarStyle = SystemBarStyle.dark(Color.TRANSPARENT),
            navigationBarStyle = SystemBarStyle.dark(Color.TRANSPARENT),
        )
        // Fond sombre de la fenêtre : aucun flash blanc pendant les animations
        window.decorView.setBackgroundColor(0xFF0E0D14.toInt())
        setContent {
            RoxiTheme { RoxiApp() }
        }
    }
}
