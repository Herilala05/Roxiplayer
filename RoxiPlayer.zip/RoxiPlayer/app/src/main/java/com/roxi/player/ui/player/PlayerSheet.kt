package com.roxi.player.ui.player

import android.content.Intent
import android.media.audiofx.AudioEffect
import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.animate
import androidx.compose.animation.core.tween
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.basicMarquee
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.Orientation
import androidx.compose.foundation.gestures.draggable
import androidx.compose.foundation.gestures.rememberDraggableState
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBars
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.wrapContentSize
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.QueueMusic
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.Equalizer
import androidx.compose.material.icons.rounded.Favorite
import androidx.compose.material.icons.rounded.FavoriteBorder
import androidx.compose.material.icons.rounded.FormatQuote
import androidx.compose.material.icons.rounded.KeyboardArrowDown
import androidx.compose.material.icons.rounded.MoreVert
import androidx.compose.material.icons.rounded.Pause
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.Repeat
import androidx.compose.material.icons.rounded.RepeatOne
import androidx.compose.material.icons.rounded.Shuffle
import androidx.compose.material.icons.rounded.SkipNext
import androidx.compose.material.icons.rounded.SkipPrevious
import androidx.compose.material.icons.rounded.Timer
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilledIconButton
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.IconButtonDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.Stable
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.lerp as lerpColor
import androidx.compose.ui.layout.layout
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Constraints
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.min
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.media3.common.Player
import com.roxi.player.data.Lyrics
import com.roxi.player.data.Song
import com.roxi.player.data.formatTime
import com.roxi.player.playback.PlaybackService
import com.roxi.player.ui.components.AlbumArt
import com.roxi.player.ui.components.LocalVm
import com.roxi.player.ui.components.SongMenu
import com.roxi.player.ui.theme.Roxi
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch
import kotlin.math.roundToInt

val MiniPlayerHeight = 64.dp

private data class SheetPx(
    val fullW: Float,
    val fullH: Float,
    val margin: Float,
    val miniH: Float,
    val collapsedTop: Float,
    val miniArt: Float,
    val miniArtPad: Float,
    val artFull: Float,
    val artXFull: Float,
    val artYFull: Float,
)

private fun lerpF(a: Float, b: Float, t: Float) = a + (b - a) * t

/**
 * État du lecteur : [fraction] = 0 → mini-lecteur, 1 → plein écran.
 * Tout (taille, position, pochette, couleurs) est calculé à partir de cette valeur.
 */
@Stable
class PlayerSheetState(private val scope: CoroutineScope) {
    var fraction by mutableFloatStateOf(0f)
        private set
    private var job: Job? = null

    fun expand() = animateTo(1f)
    fun collapse() = animateTo(0f)
    fun stop() {
        job?.cancel()
    }

    fun dragBy(delta: Float) {
        job?.cancel()
        fraction = (fraction + delta).coerceIn(0f, 1f)
    }

    /** Au relâchement : on va vers le plus proche, ou dans le sens du geste s'il est rapide. */
    fun settle(velocity: Float) {
        val target = when {
            velocity > 1.2f -> 1f
            velocity < -1.2f -> 0f
            fraction > 0.5f -> 1f
            else -> 0f
        }
        animateTo(target)
    }

    private fun animateTo(target: Float) {
        job?.cancel()
        job = scope.launch {
            animate(
                initialValue = fraction,
                targetValue = target,
                animationSpec = tween(durationMillis = 320, easing = FastOutSlowInEasing),
            ) { value, _ -> fraction = value }
        }
    }
}

@Composable
fun rememberPlayerSheetState(): PlayerSheetState {
    val scope = rememberCoroutineScope()
    return remember { PlayerSheetState(scope) }
}

/**
 * Panneau superposé à l'écran actuel (l'écran d'accueil reste visible dessous).
 * Transition « container transform » : la pochette du mini-lecteur grossit sur place.
 * [collapsedBottom] = espace sous le mini-lecteur (barre de navigation).
 */
@Composable
fun PlayerSheet(state: PlayerSheetState, song: Song, collapsedBottom: Dp) {
    BoxWithConstraints(Modifier.fillMaxSize()) {
        val density = LocalDensity.current
        val fullW = maxWidth
        val fullH = maxHeight
        val statusTop = with(density) { WindowInsets.statusBars.getTop(this).toDp() }
        val navBottom = with(density) { WindowInsets.navigationBars.getBottom(this).toDp() }

        val margin = 8.dp
        val miniArt = 48.dp
        val miniArtPad = 8.dp
        val artFull = min(fullW - 64.dp, fullH * 0.42f)
        val artTopFull = statusTop + 56.dp + 24.dp
        val collapsedTop = fullH - collapsedBottom - MiniPlayerHeight - 6.dp

        val px = with(density) {
            SheetPx(
                fullW = fullW.toPx(),
                fullH = fullH.toPx(),
                margin = margin.toPx(),
                miniH = MiniPlayerHeight.toPx(),
                collapsedTop = collapsedTop.toPx(),
                miniArt = miniArt.toPx(),
                miniArtPad = miniArtPad.toPx(),
                artFull = artFull.toPx(),
                artXFull = ((fullW - artFull) / 2).toPx(),
                artYFull = artTopFull.toPx(),
            )
        }
        val dragRange = px.collapsedTop.coerceAtLeast(1f)

        val expanded by remember { derivedStateOf { state.fraction > 0.5f } }
        val showScrim by remember { derivedStateOf { state.fraction > 0.001f } }
        BackHandler(enabled = expanded) { state.collapse() }

        if (showScrim) {
            Box(
                Modifier
                    .fillMaxSize()
                    .graphicsLayer { alpha = state.fraction * 0.6f }
                    .background(Color.Black)
            )
        }

        val dragState = rememberDraggableState { delta -> state.dragBy(-delta / dragRange) }

        Box(
            Modifier
                .offset {
                    val f = state.fraction
                    IntOffset(lerpF(px.margin, 0f, f).roundToInt(), lerpF(px.collapsedTop, 0f, f).roundToInt())
                }
                .layout { measurable, _ ->
                    val f = state.fraction
                    val w = lerpF(px.fullW - 2 * px.margin, px.fullW, f).roundToInt()
                    val h = lerpF(px.miniH, px.fullH, f).roundToInt()
                    val placeable = measurable.measure(Constraints.fixed(w, h))
                    layout(w, h) { placeable.place(0, 0) }
                }
                .graphicsLayer {
                    shape = RoundedCornerShape(lerpF(14f, 0f, state.fraction).dp)
                    clip = true
                }
                .drawBehind { drawRect(lerpColor(Roxi.SurfaceHigh, Roxi.Bg, state.fraction)) }
                .draggable(
                    state = dragState,
                    orientation = Orientation.Vertical,
                    onDragStarted = { state.stop() },
                    onDragStopped = { velocity -> state.settle(-velocity / dragRange) },
                )
        ) {
            // 1. Lecteur plein écran (dessiné à taille réelle, révélé en fin d'animation)
            FullPlayer(
                song = song,
                state = state,
                statusTop = statusTop,
                navBottom = navBottom,
                artSize = artFull,
                modifier = Modifier
                    .wrapContentSize(Alignment.TopStart, unbounded = true)
                    .size(fullW, fullH)
                    .graphicsLayer { alpha = ((state.fraction - 0.45f) / 0.55f).coerceIn(0f, 1f) },
            )

            // 2. La pochette : UNE seule image qui se déplace et grossit
            Box(
                Modifier
                    .offset {
                        val f = state.fraction
                        IntOffset(
                            lerpF(px.miniArtPad, px.artXFull, f).roundToInt(),
                            lerpF(px.miniArtPad, px.artYFull, f).roundToInt(),
                        )
                    }
                    .layout { measurable, _ ->
                        val s = lerpF(px.miniArt, px.artFull, state.fraction).roundToInt()
                        val placeable = measurable.measure(Constraints.fixed(s, s))
                        layout(s, s) { placeable.place(0, 0) }
                    }
                    .graphicsLayer {
                        shape = RoundedCornerShape(lerpF(8f, 22f, state.fraction).dp)
                        clip = true
                    }
            ) {
                AlbumArt(song, Modifier.fillMaxSize(), size = 720)
            }

            // 3. Mini-lecteur (seulement quand le panneau est fermé)
            if (!expanded) {
                Box(
                    Modifier
                        .fillMaxSize()
                        .clickable(
                            interactionSource = remember { MutableInteractionSource() },
                            indication = null,
                        ) { state.expand() }
                )
                MiniPlayer(
                    song,
                    Modifier
                        .fillMaxWidth()
                        .height(MiniPlayerHeight)
                        .graphicsLayer { alpha = (1f - state.fraction / 0.3f).coerceIn(0f, 1f) },
                )
            }
        }
    }
}

@Composable
private fun MiniPlayer(song: Song, modifier: Modifier) {
    val vm = LocalVm.current
    val ui by vm.player.state.collectAsStateWithLifecycle()
    Box(modifier) {
        Row(
            Modifier
                .fillMaxSize()
                .padding(start = 66.dp, end = 4.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Column(Modifier.weight(1f)) {
                Text(
                    song.title,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                    style = MaterialTheme.typography.bodyMedium,
                    fontWeight = FontWeight.SemiBold,
                )
                Text(
                    song.artist,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                    style = MaterialTheme.typography.bodySmall,
                    color = Roxi.TextSub,
                )
            }
            IconButton(onClick = { vm.player.previous() }) {
                Icon(Icons.Rounded.SkipPrevious, "Précédent")
            }
            IconButton(onClick = { vm.player.togglePlay() }) {
                Icon(if (ui.isPlaying) Icons.Rounded.Pause else Icons.Rounded.PlayArrow, "Lecture")
            }
            IconButton(onClick = { vm.player.next() }) {
                Icon(Icons.Rounded.SkipNext, "Suivant")
            }
        }
        val duration = ui.durationMs.takeIf { it > 0 } ?: song.durationMs
        val progress = (ui.positionMs.toFloat() / duration.coerceAtLeast(1L)).coerceIn(0f, 1f)
        Box(
            Modifier
                .align(Alignment.BottomStart)
                .padding(horizontal = 12.dp)
                .fillMaxWidth(progress)
                .height(2.dp)
                .background(Roxi.VioletSoft)
        )
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun FullPlayer(
    song: Song,
    state: PlayerSheetState,
    statusTop: Dp,
    navBottom: Dp,
    artSize: Dp,
    modifier: Modifier,
) {
    val vm = LocalVm.current
    val context = LocalContext.current
    val ui by vm.player.state.collectAsStateWithLifecycle()
    val liked by vm.prefs.liked.collectAsStateWithLifecycle()
    var menu by remember { mutableStateOf(false) }
    var showQueue by remember { mutableStateOf(false) }
    var showLyrics by remember { mutableStateOf(false) }
    var showSleep by remember { mutableStateOf(false) }
    val eqLauncher = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) {}

    Column(modifier) {
        Spacer(Modifier.height(statusTop))
        Row(
            Modifier
                .fillMaxWidth()
                .height(56.dp)
                .padding(horizontal = 8.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            IconButton(onClick = { state.collapse() }) {
                Icon(Icons.Rounded.KeyboardArrowDown, "Réduire", Modifier.size(30.dp))
            }
            Text(
                "Lecture en cours",
                style = MaterialTheme.typography.titleMedium,
                modifier = Modifier.weight(1f),
            )
            Box {
                IconButton(onClick = { menu = true }) { Icon(Icons.Rounded.MoreVert, "Options") }
                SongMenu(
                    song = song,
                    expanded = menu,
                    onDismiss = { menu = false },
                    showQueueActions = false,
                    extraMenu = { close ->
                        DropdownMenuItem(
                            text = { Text("Minuterie de sommeil") },
                            leadingIcon = { Icon(Icons.Rounded.Timer, null) },
                            onClick = {
                                showSleep = true
                                close()
                            },
                        )
                    },
                )
            }
        }
        Spacer(Modifier.height(24.dp))
        Spacer(Modifier.height(artSize)) // place réservée à la pochette animée
        Spacer(Modifier.height(28.dp))

        Row(Modifier.padding(horizontal = 24.dp), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text(
                    song.title,
                    style = MaterialTheme.typography.titleLarge,
                    fontWeight = FontWeight.SemiBold,
                    maxLines = 1,
                    modifier = Modifier.basicMarquee(),
                )
                Text(
                    song.artist,
                    style = MaterialTheme.typography.bodyMedium,
                    color = Roxi.TextSub,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                )
            }
            val isLiked = song.id in liked
            IconButton(onClick = { vm.toggleLike(song) }) {
                Icon(
                    if (isLiked) Icons.Rounded.Favorite else Icons.Rounded.FavoriteBorder,
                    "J'aime",
                    tint = if (isLiked) Roxi.Pink else Roxi.Text,
                )
            }
        }

        // Barre de progression
        var dragging by remember { mutableStateOf(false) }
        var dragValue by remember { mutableFloatStateOf(0f) }
        val duration = ui.durationMs.takeIf { it > 0 } ?: song.durationMs
        val progress = if (dragging) dragValue else (ui.positionMs.toFloat() / duration.coerceAtLeast(1L)).coerceIn(0f, 1f)
        Slider(
            value = progress,
            onValueChange = {
                dragging = true
                dragValue = it
            },
            onValueChangeFinished = {
                vm.player.seekTo((dragValue * duration).toLong())
                dragging = false
            },
            colors = SliderDefaults.colors(
                thumbColor = Roxi.VioletSoft,
                activeTrackColor = Roxi.VioletSoft,
                inactiveTrackColor = Roxi.SurfaceHigh,
            ),
            modifier = Modifier.padding(horizontal = 16.dp, vertical = 4.dp),
        )
        Row(Modifier.padding(horizontal = 24.dp)) {
            Text(
                formatTime(if (dragging) (dragValue * duration).toLong() else ui.positionMs),
                style = MaterialTheme.typography.labelMedium,
                color = Roxi.TextSub,
            )
            Spacer(Modifier.weight(1f))
            Text(formatTime(duration), style = MaterialTheme.typography.labelMedium, color = Roxi.TextSub)
        }

        Spacer(Modifier.height(12.dp))
        Row(
            Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceEvenly,
            verticalAlignment = Alignment.CenterVertically,
        ) {
            IconButton(onClick = { vm.player.toggleShuffle() }) {
                Icon(
                    Icons.Rounded.Shuffle, "Aléatoire",
                    tint = if (ui.shuffle) Roxi.VioletSoft else Roxi.TextSub,
                )
            }
            IconButton(onClick = { vm.player.previous() }, modifier = Modifier.size(56.dp)) {
                Icon(Icons.Rounded.SkipPrevious, "Précédent", Modifier.size(36.dp))
            }
            FilledIconButton(
                onClick = { vm.player.togglePlay() },
                modifier = Modifier.size(72.dp),
                colors = IconButtonDefaults.filledIconButtonColors(
                    containerColor = Roxi.VioletSoft,
                    contentColor = Color(0xFF1E1147),
                ),
            ) {
                Icon(
                    if (ui.isPlaying) Icons.Rounded.Pause else Icons.Rounded.PlayArrow,
                    "Lecture",
                    Modifier.size(40.dp),
                )
            }
            IconButton(onClick = { vm.player.next() }, modifier = Modifier.size(56.dp)) {
                Icon(Icons.Rounded.SkipNext, "Suivant", Modifier.size(36.dp))
            }
            IconButton(onClick = { vm.player.cycleRepeat() }) {
                Icon(
                    if (ui.repeatMode == Player.REPEAT_MODE_ONE) Icons.Rounded.RepeatOne else Icons.Rounded.Repeat,
                    "Répétition",
                    tint = if (ui.repeatMode != Player.REPEAT_MODE_OFF) Roxi.VioletSoft else Roxi.TextSub,
                )
            }
        }

        Spacer(Modifier.weight(1f))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
            BottomAction(Icons.Rounded.Equalizer, "Égaliseur") {
                val intent = Intent(AudioEffect.ACTION_DISPLAY_AUDIO_EFFECT_CONTROL_PANEL).apply {
                    putExtra(AudioEffect.EXTRA_AUDIO_SESSION, PlaybackService.audioSessionId)
                    putExtra(AudioEffect.EXTRA_PACKAGE_NAME, context.packageName)
                    putExtra(AudioEffect.EXTRA_CONTENT_TYPE, AudioEffect.CONTENT_TYPE_MUSIC)
                }
                try {
                    eqLauncher.launch(intent)
                } catch (e: Exception) {
                    Toast.makeText(context, "Aucun égaliseur disponible sur ce téléphone", Toast.LENGTH_SHORT).show()
                }
            }
            BottomAction(Icons.Rounded.FormatQuote, "Paroles") { showLyrics = true }
            BottomAction(Icons.AutoMirrored.Rounded.QueueMusic, "File d'attente") { showQueue = true }
        }
        Spacer(Modifier.height(navBottom + 16.dp))
    }

    if (showQueue) QueueSheet { showQueue = false }
    if (showLyrics) LyricsSheet(song) { showLyrics = false }
    if (showSleep) SleepTimerDialog { showSleep = false }
}

@Composable
private fun BottomAction(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    label: String,
    onClick: () -> Unit,
) {
    Column(
        Modifier
            .clip(RoundedCornerShape(12.dp))
            .clickable(onClick = onClick)
            .padding(horizontal = 12.dp, vertical = 6.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Icon(icon, label, tint = Roxi.Text)
        Text(label, style = MaterialTheme.typography.labelSmall, color = Roxi.TextSub)
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun QueueSheet(onDismiss: () -> Unit) {
    val vm = LocalVm.current
    val ui by vm.player.state.collectAsStateWithLifecycle()
    val map by vm.songMap.collectAsStateWithLifecycle()
    val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)
    ModalBottomSheet(onDismissRequest = onDismiss, sheetState = sheetState, containerColor = Roxi.Surface) {
        Text(
            "File d'attente (${ui.queue.size})",
            style = MaterialTheme.typography.titleMedium,
            fontWeight = FontWeight.SemiBold,
            modifier = Modifier.padding(horizontal = 20.dp, vertical = 8.dp),
        )
        HorizontalDivider()
        val startPos = ui.queue.indexOfFirst { it.index == ui.queueIndex }.coerceAtLeast(0)
        val listState = rememberLazyListState(initialFirstVisibleItemIndex = (startPos - 2).coerceAtLeast(0))
        LazyColumn(
            state = listState,
            modifier = Modifier
                .fillMaxWidth()
                .fillMaxHeight(0.75f),
        ) {
            itemsIndexed(ui.queue) { _, entry ->
                val s = map[entry.songId] ?: return@itemsIndexed
                val isCurrent = entry.index == ui.queueIndex
                Row(
                    Modifier
                        .fillMaxWidth()
                        .clickable { vm.player.skipTo(entry.index) }
                        .background(if (isCurrent) Roxi.SurfaceHigh else Color.Transparent)
                        .padding(start = 20.dp, end = 4.dp, top = 6.dp, bottom = 6.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    AlbumArt(s, Modifier.size(44.dp).clip(RoundedCornerShape(6.dp)))
                    Spacer(Modifier.width(12.dp))
                    Column(Modifier.weight(1f)) {
                        Text(
                            s.title, maxLines = 1, overflow = TextOverflow.Ellipsis,
                            color = if (isCurrent) Roxi.VioletSoft else Roxi.Text,
                        )
                        Text(
                            s.artist, maxLines = 1, overflow = TextOverflow.Ellipsis,
                            style = MaterialTheme.typography.bodySmall, color = Roxi.TextSub,
                        )
                    }
                    if (isCurrent) {
                        Icon(Icons.Rounded.Equalizer, null, tint = Roxi.VioletSoft, modifier = Modifier.padding(12.dp))
                    } else {
                        IconButton(onClick = { vm.player.removeFromQueue(entry.index) }) {
                            Icon(Icons.Rounded.Close, "Retirer", tint = Roxi.TextSub)
                        }
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun LyricsSheet(song: Song, onDismiss: () -> Unit) {
    val vm = LocalVm.current
    val ui by vm.player.state.collectAsStateWithLifecycle()
    val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)
    val lyrics by produceState<Lyrics?>(null, song.id) { value = vm.lyrics.getLyrics(song) }

    ModalBottomSheet(onDismissRequest = onDismiss, sheetState = sheetState, containerColor = Roxi.Surface) {
        Row(Modifier.padding(horizontal = 20.dp, vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Rounded.FormatQuote, null, tint = Roxi.VioletSoft)
            Spacer(Modifier.width(8.dp))
            Text(
                song.title, maxLines = 1, overflow = TextOverflow.Ellipsis,
                style = MaterialTheme.typography.titleMedium,
            )
        }
        HorizontalDivider()
        Box(
            Modifier
                .fillMaxWidth()
                .fillMaxHeight(0.7f)
        ) {
            when (val l = lyrics) {
                null -> CircularProgressIndicator(Modifier.align(Alignment.Center))
                Lyrics.None -> Column(
                    Modifier
                        .align(Alignment.Center)
                        .padding(32.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                ) {
                    Text("Paroles non disponibles pour ce morceau.", textAlign = TextAlign.Center)
                    Spacer(Modifier.height(12.dp))
                    Text(
                        "Astuce : mets un fichier .lrc portant exactement le même nom que la chanson " +
                            "dans ton dossier des paroles (onglet Moi → Dossier des paroles).",
                        style = MaterialTheme.typography.bodySmall,
                        color = Roxi.TextSub,
                        textAlign = TextAlign.Center,
                    )
                }
                is Lyrics.Plain -> Text(
                    l.text,
                    style = MaterialTheme.typography.bodyLarge,
                    modifier = Modifier
                        .verticalScroll(rememberScrollState())
                        .padding(24.dp),
                )
                is Lyrics.Synced -> SyncedLyrics(l, ui.positionMs) { vm.player.seekTo(it) }
            }
        }
    }
}

@Composable
private fun SyncedLyrics(lyrics: Lyrics.Synced, positionMs: Long, onSeek: (Long) -> Unit) {
    val current = remember(positionMs, lyrics) { lyrics.lines.indexOfLast { it.timeMs <= positionMs } }
    val listState = rememberLazyListState()
    LaunchedEffect(current) {
        if (current >= 0) listState.animateScrollToItem((current - 3).coerceAtLeast(0))
    }
    LazyColumn(state = listState, modifier = Modifier.fillMaxSize()) {
        itemsIndexed(lyrics.lines) { i, line ->
            val active = i == current
            Text(
                line.text.ifBlank { "♪" },
                style = if (active) MaterialTheme.typography.titleLarge else MaterialTheme.typography.titleMedium,
                fontWeight = if (active) FontWeight.Bold else FontWeight.Normal,
                color = if (active) Roxi.Text else Roxi.TextSub,
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { onSeek(line.timeMs) }
                    .padding(horizontal = 24.dp, vertical = 8.dp),
            )
        }
    }
}

@Composable
fun SleepTimerDialog(onDismiss: () -> Unit) {
    val vm = LocalVm.current
    val end by vm.sleepTimerEnd.collectAsStateWithLifecycle()
    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = Roxi.Surface,
        title = { Text("Minuterie de sommeil") },
        text = {
            Column {
                Text(vm.sleepTimerLabel(end), color = Roxi.TextSub)
                Spacer(Modifier.height(8.dp))
                listOf(15, 30, 45, 60, 90).forEach { m ->
                    Text(
                        "$m minutes",
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(8.dp))
                            .clickable {
                                vm.setSleepTimer(m)
                                onDismiss()
                            }
                            .padding(vertical = 12.dp, horizontal = 8.dp),
                    )
                }
            }
        },
        confirmButton = {
            TextButton(onClick = {
                vm.setSleepTimer(null)
                onDismiss()
            }) { Text("Désactiver") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Fermer") } },
    )
}
