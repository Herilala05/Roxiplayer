package com.roxi.player.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

object Roxi {
    val Bg = Color(0xFF0E0D14)
    val Surface = Color(0xFF1C1B24)
    val SurfaceHigh = Color(0xFF282634)
    val Violet = Color(0xFF7B5CF0)
    val VioletSoft = Color(0xFFB9A8FF)
    val Pink = Color(0xFFE84C88)
    val Blue = Color(0xFF4FA3F7)
    val Text = Color(0xFFF2F1F7)
    val TextSub = Color(0xFF9E9CAB)
}

private val scheme = darkColorScheme(
    primary = Roxi.VioletSoft,
    onPrimary = Color(0xFF1E1147),
    primaryContainer = Roxi.Violet,
    onPrimaryContainer = Color.White,
    secondary = Roxi.Pink,
    onSecondary = Color.White,
    background = Roxi.Bg,
    onBackground = Roxi.Text,
    surface = Roxi.Bg,
    onSurface = Roxi.Text,
    surfaceVariant = Roxi.SurfaceHigh,
    onSurfaceVariant = Roxi.TextSub,
    surfaceContainerLowest = Roxi.Bg,
    surfaceContainerLow = Roxi.Surface,
    surfaceContainer = Roxi.Surface,
    surfaceContainerHigh = Roxi.SurfaceHigh,
    surfaceContainerHighest = Roxi.SurfaceHigh,
    outline = Color(0xFF4A4858),
)

@Composable
fun RoxiTheme(content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = scheme, content = content)
}
