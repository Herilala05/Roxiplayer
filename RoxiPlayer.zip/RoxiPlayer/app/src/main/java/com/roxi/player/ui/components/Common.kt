package com.roxi.player.ui.components

import android.content.Intent
import android.text.format.DateFormat
import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.automirrored.rounded.PlaylistAdd
import androidx.compose.material.icons.automirrored.rounded.QueueMusic
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.Favorite
import androidx.compose.material.icons.rounded.FavoriteBorder
import androidx.compose.material.icons.rounded.Info
import androidx.compose.material.icons.rounded.MoreVert
import androidx.compose.material.icons.rounded.Share
import androidx.compose.material.icons.rounded.SkipNext
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.roxi.player.MainViewModel
import com.roxi.player.data.Song
import com.roxi.player.data.formatTime
import com.roxi.player.ui.theme.Roxi
import java.util.Date

val LocalVm = staticCompositionLocalOf<MainViewModel> { error("ViewModel non fourni") }

/** Espace à laisser en bas des listes (barre de navigation + mini-lecteur). */
val LocalBottomPadding = staticCompositionLocalOf { 0.dp }

@Composable
fun SectionHeader(title: String, onSeeAll: (() -> Unit)? = null) {
    Row(
        Modifier
            .fillMaxWidth()
            .padding(start = 16.dp, end = 8.dp, top = 20.dp, bottom = 8.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Text(
            title,
            style = MaterialTheme.typography.titleMedium,
            fontWeight = FontWeight.SemiBold,
            modifier = Modifier.weight(1f),
        )
        if (onSeeAll != null) {
            TextButton(onClick = onSeeAll) { Text("Voir tout") }
        }
    }
}

@Composable
fun LyricsBadge() {
    Text(
        "PAROLES",
        fontSize = 9.sp,
        fontWeight = FontWeight.Bold,
        color = Roxi.TextSub,
        modifier = Modifier
            .clip(RoundedCornerShape(4.dp))
            .background(Roxi.SurfaceHigh)
            .padding(horizontal = 5.dp, vertical = 1.dp),
    )
}

/**
 * Ligne d'un morceau avec pochette, badge PAROLES, artiste et menu « ⋮ ».
 * [extraMenu] permet d'ajouter des actions (ex. dans une playlist).
 */
@Composable
fun SongRow(
    song: Song,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    extraMenu: (@Composable ColumnScope.(close: () -> Unit) -> Unit)? = null,
) {
    val vm = LocalVm.current
    val current by vm.currentSong.collectAsStateWithLifecycle()
    val isCurrent = current?.id == song.id
    val hasLyrics by produceState(false, song.id) { value = vm.lyrics.hasLyrics(song) }
    var menu by remember { mutableStateOf(false) }

    Row(
        modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .padding(start = 16.dp, end = 4.dp, top = 6.dp, bottom = 6.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        AlbumArt(song, Modifier.size(48.dp).clip(RoundedCornerShape(8.dp)))
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text(
                song.title,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
                style = MaterialTheme.typography.bodyLarge,
                color = if (isCurrent) Roxi.VioletSoft else Roxi.Text,
                fontWeight = if (isCurrent) FontWeight.SemiBold else FontWeight.Normal,
            )
            Row(verticalAlignment = Alignment.CenterVertically) {
                if (hasLyrics) {
                    LyricsBadge()
                    Spacer(Modifier.width(6.dp))
                }
                Text(
                    song.artist,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                    style = MaterialTheme.typography.bodySmall,
                    color = Roxi.TextSub,
                )
            }
        }
        Box {
            IconButton(onClick = { menu = true }) {
                Icon(Icons.Rounded.MoreVert, contentDescription = "Options", tint = Roxi.TextSub)
            }
            SongMenu(song, expanded = menu, onDismiss = { menu = false }, extraMenu = extraMenu)
        }
    }
}

/** Menu d'options d'un morceau (réutilisé dans le lecteur). */
@Composable
fun SongMenu(
    song: Song,
    expanded: Boolean,
    onDismiss: () -> Unit,
    showQueueActions: Boolean = true,
    extraMenu: (@Composable ColumnScope.(close: () -> Unit) -> Unit)? = null,
) {
    val vm = LocalVm.current
    val context = LocalContext.current
    val liked by vm.prefs.liked.collectAsStateWithLifecycle()
    var addDialog by remember { mutableStateOf(false) }
    var infoDialog by remember { mutableStateOf(false) }

    DropdownMenu(expanded = expanded, onDismissRequest = onDismiss) {
        if (showQueueActions) {
            DropdownMenuItem(
                text = { Text("Lire ensuite") },
                leadingIcon = { Icon(Icons.Rounded.SkipNext, null) },
                onClick = {
                    vm.player.playNext(song)
                    Toast.makeText(context, "Sera lu ensuite", Toast.LENGTH_SHORT).show()
                    onDismiss()
                },
            )
            DropdownMenuItem(
                text = { Text("Ajouter à la file d'attente") },
                leadingIcon = { Icon(Icons.AutoMirrored.Rounded.QueueMusic, null) },
                onClick = {
                    vm.player.addToQueue(song)
                    Toast.makeText(context, "Ajouté à la file d'attente", Toast.LENGTH_SHORT).show()
                    onDismiss()
                },
            )
        }
        DropdownMenuItem(
            text = { Text("Ajouter à une playlist") },
            leadingIcon = { Icon(Icons.AutoMirrored.Rounded.PlaylistAdd, null) },
            onClick = {
                addDialog = true
                onDismiss()
            },
        )
        val isLiked = song.id in liked
        DropdownMenuItem(
            text = { Text(if (isLiked) "Retirer des favoris" else "Ajouter aux favoris") },
            leadingIcon = {
                Icon(if (isLiked) Icons.Rounded.Favorite else Icons.Rounded.FavoriteBorder, null)
            },
            onClick = {
                vm.toggleLike(song)
                onDismiss()
            },
        )
        DropdownMenuItem(
            text = { Text("Infos") },
            leadingIcon = { Icon(Icons.Rounded.Info, null) },
            onClick = {
                infoDialog = true
                onDismiss()
            },
        )
        DropdownMenuItem(
            text = { Text("Partager") },
            leadingIcon = { Icon(Icons.Rounded.Share, null) },
            onClick = {
                onDismiss()
                try {
                    val send = Intent(Intent.ACTION_SEND).apply {
                        type = "audio/*"
                        putExtra(Intent.EXTRA_STREAM, song.uri)
                        addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                    }
                    context.startActivity(Intent.createChooser(send, "Partager ${song.title}"))
                } catch (e: Exception) {
                    Toast.makeText(context, "Partage impossible", Toast.LENGTH_SHORT).show()
                }
            },
        )
        if (extraMenu != null) {
            HorizontalDivider()
            extraMenu(onDismiss)
        }
    }

    if (addDialog) AddToPlaylistDialog(song) { addDialog = false }
    if (infoDialog) SongInfoDialog(song) { infoDialog = false }
}

@Composable
fun AddToPlaylistDialog(song: Song, onDismiss: () -> Unit) {
    val vm = LocalVm.current
    val context = LocalContext.current
    val playlists by vm.prefs.playlists.collectAsStateWithLifecycle()
    var newName by remember { mutableStateOf("") }

    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = Roxi.Surface,
        title = { Text("Ajouter à une playlist") },
        text = {
            Column {
                LazyColumn(Modifier.heightIn(max = 260.dp)) {
                    items(playlists, key = { it.id }) { p ->
                        Text(
                            "${p.name}  (${p.songIds.size})",
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(8.dp))
                                .clickable {
                                    vm.prefs.addToPlaylist(p.id, song.id)
                                    Toast.makeText(context, "Ajouté à ${p.name}", Toast.LENGTH_SHORT).show()
                                    onDismiss()
                                }
                                .padding(vertical = 12.dp, horizontal = 8.dp),
                        )
                    }
                }
                Spacer(Modifier.height(8.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    OutlinedTextField(
                        value = newName,
                        onValueChange = { newName = it },
                        label = { Text("Nouvelle playlist") },
                        singleLine = true,
                        modifier = Modifier.weight(1f),
                    )
                    IconButton(
                        enabled = newName.isNotBlank(),
                        onClick = {
                            val id = vm.prefs.createPlaylist(newName)
                            vm.prefs.addToPlaylist(id, song.id)
                            Toast.makeText(context, "Playlist créée", Toast.LENGTH_SHORT).show()
                            onDismiss()
                        },
                    ) { Icon(Icons.Rounded.Add, "Créer") }
                }
            }
        },
        confirmButton = { TextButton(onClick = onDismiss) { Text("Fermer") } },
    )
}

@Composable
fun SongInfoDialog(song: Song, onDismiss: () -> Unit) {
    val context = LocalContext.current
    val date = DateFormat.getDateFormat(context).format(Date(song.dateAdded * 1000))
    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = Roxi.Surface,
        title = { Text(song.title) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                InfoLine("Artiste", song.artist)
                InfoLine("Album", song.album)
                InfoLine("Durée", formatTime(song.durationMs))
                InfoLine("Taille", "%.1f Mo".format(song.size / 1_048_576f))
                InfoLine("Ajouté le", date)
                InfoLine("Emplacement", song.path)
            }
        },
        confirmButton = { TextButton(onClick = onDismiss) { Text("OK") } },
    )
}

@Composable
private fun InfoLine(label: String, value: String) {
    Column {
        Text(label, style = MaterialTheme.typography.labelSmall, color = Roxi.TextSub)
        Text(value, style = MaterialTheme.typography.bodyMedium)
    }
}

@Composable
fun ScreenHeader(title: String, onBack: (() -> Unit)?, actions: @Composable () -> Unit = {}) {
    Row(
        Modifier
            .fillMaxWidth()
            .height(56.dp)
            .padding(horizontal = 4.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        if (onBack != null) {
            IconButton(onClick = onBack) {
                Icon(
                    Icons.AutoMirrored.Rounded.ArrowBack,
                    contentDescription = "Retour",
                )
            }
        } else {
            Spacer(Modifier.width(12.dp))
        }
        Text(
            title,
            style = MaterialTheme.typography.titleLarge,
            fontWeight = FontWeight.SemiBold,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
            modifier = Modifier.weight(1f),
        )
        actions()
    }
}

