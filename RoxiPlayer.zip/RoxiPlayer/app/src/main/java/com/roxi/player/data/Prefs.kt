package com.roxi.player.data

import android.content.Context
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import org.json.JSONArray
import org.json.JSONObject
import java.util.Collections

/** Stockage local simple : favoris, playlists, historique, réglages. */
class Prefs(context: Context) {
    private val sp = context.getSharedPreferences("roxi_prefs", Context.MODE_PRIVATE)

    // ---------- Favoris (plus récent en premier) ----------
    private val _liked = MutableStateFlow(readIdList("liked"))
    val liked: StateFlow<List<Long>> = _liked.asStateFlow()

    fun toggleLike(id: Long) {
        val cur = _liked.value
        val next = if (id in cur) cur - id else listOf(id) + cur
        _liked.value = next
        writeIdList("liked", next)
    }

    // ---------- Playlists ----------
    private val _playlists = MutableStateFlow(readPlaylists())
    val playlists: StateFlow<List<Playlist>> = _playlists.asStateFlow()

    fun createPlaylist(name: String): Long {
        val id = System.currentTimeMillis()
        savePlaylists(_playlists.value + Playlist(id, name.trim().ifEmpty { "Nouvelle playlist" }, emptyList()))
        return id
    }

    fun renamePlaylist(id: Long, name: String) = savePlaylists(
        _playlists.value.map { if (it.id == id) it.copy(name = name.trim().ifEmpty { it.name }) else it }
    )

    fun deletePlaylist(id: Long) = savePlaylists(_playlists.value.filterNot { it.id == id })

    fun addToPlaylist(id: Long, songId: Long) = savePlaylists(
        _playlists.value.map {
            if (it.id == id && songId !in it.songIds) it.copy(songIds = it.songIds + songId) else it
        }
    )

    fun removeFromPlaylist(id: Long, songId: Long) = savePlaylists(
        _playlists.value.map { if (it.id == id) it.copy(songIds = it.songIds - songId) else it }
    )

    fun moveInPlaylist(id: Long, songId: Long, delta: Int) = savePlaylists(
        _playlists.value.map { p ->
            if (p.id != id) return@map p
            val list = p.songIds.toMutableList()
            val i = list.indexOf(songId)
            val j = i + delta
            if (i < 0 || j !in list.indices) p else {
                Collections.swap(list, i, j)
                p.copy(songIds = list)
            }
        }
    )

    private fun savePlaylists(list: List<Playlist>) {
        _playlists.value = list
        val arr = JSONArray()
        list.forEach { p ->
            arr.put(
                JSONObject()
                    .put("id", p.id)
                    .put("name", p.name)
                    .put("songs", JSONArray().apply { p.songIds.forEach { put(it) } })
            )
        }
        sp.edit().putString("playlists", arr.toString()).apply()
    }

    private fun readPlaylists(): List<Playlist> = try {
        val arr = JSONArray(sp.getString("playlists", "[]"))
        (0 until arr.length()).map { i ->
            val o = arr.getJSONObject(i)
            val songs = o.getJSONArray("songs")
            Playlist(o.getLong("id"), o.getString("name"), (0 until songs.length()).map { songs.getLong(it) })
        }
    } catch (e: Exception) {
        emptyList()
    }

    // ---------- Historique d'écoute ----------
    private val _recent = MutableStateFlow(readIdList("recent"))
    val recent: StateFlow<List<Long>> = _recent.asStateFlow()

    private val _playCounts = MutableStateFlow(readCounts())
    val playCounts: StateFlow<Map<Long, Int>> = _playCounts.asStateFlow()

    fun recordPlay(id: Long) {
        val next = (listOf(id) + (_recent.value - id)).take(50)
        _recent.value = next
        writeIdList("recent", next)
        val counts = _playCounts.value.toMutableMap()
        counts[id] = (counts[id] ?: 0) + 1
        _playCounts.value = counts
        val o = JSONObject()
        counts.forEach { (k, v) -> o.put(k.toString(), v) }
        sp.edit().putString("counts", o.toString()).apply()
    }

    private fun readCounts(): Map<Long, Int> = try {
        val o = JSONObject(sp.getString("counts", "{}") ?: "{}")
        o.keys().asSequence().mapNotNull { k -> k.toLongOrNull()?.let { it to o.getInt(k) } }.toMap()
    } catch (e: Exception) {
        emptyMap()
    }

    // ---------- Temps d'écoute total ----------
    private val _listenMs = MutableStateFlow(sp.getLong("listen_ms", 0L))
    val listenMs: StateFlow<Long> = _listenMs.asStateFlow()
    private var pendingListen = 0L

    fun addListen(ms: Long) {
        _listenMs.value += ms
        pendingListen += ms
        if (pendingListen >= 10_000L) flushListen()
    }

    fun flushListen() {
        pendingListen = 0L
        sp.edit().putLong("listen_ms", _listenMs.value).apply()
    }

    // ---------- Réglages ----------
    private val _sortOrder = MutableStateFlow(
        SortOrder.entries.getOrElse(sp.getInt("sort", 0)) { SortOrder.DATE_DESC }
    )
    val sortOrder: StateFlow<SortOrder> = _sortOrder.asStateFlow()
    fun setSortOrder(order: SortOrder) {
        _sortOrder.value = order
        sp.edit().putInt("sort", order.ordinal).apply()
    }

    private val _minDurationSec = MutableStateFlow(sp.getInt("min_duration", 30))
    val minDurationSec: StateFlow<Int> = _minDurationSec.asStateFlow()
    fun setMinDuration(sec: Int) {
        _minDurationSec.value = sec
        sp.edit().putInt("min_duration", sec).apply()
    }

    private val _lyricsTree = MutableStateFlow(sp.getString("lyrics_tree", null))
    val lyricsTree: StateFlow<String?> = _lyricsTree.asStateFlow()
    fun setLyricsTree(uri: String?) {
        _lyricsTree.value = uri
        sp.edit().putString("lyrics_tree", uri).apply()
    }

    // ---------- Reprise de la dernière lecture ----------
    var lastSongId: Long
        get() = sp.getLong("last_id", -1L)
        set(value) = sp.edit().putLong("last_id", value).apply()

    var lastPosition: Long
        get() = sp.getLong("last_pos", 0L)
        set(value) = sp.edit().putLong("last_pos", value).apply()

    // ---------- Utilitaires ----------
    private fun readIdList(key: String): List<Long> = try {
        val arr = JSONArray(sp.getString(key, "[]"))
        (0 until arr.length()).map { arr.getLong(it) }
    } catch (e: Exception) {
        emptyList()
    }

    private fun writeIdList(key: String, list: List<Long>) {
        val arr = JSONArray()
        list.forEach { arr.put(it) }
        sp.edit().putString(key, arr.toString()).apply()
    }
}
