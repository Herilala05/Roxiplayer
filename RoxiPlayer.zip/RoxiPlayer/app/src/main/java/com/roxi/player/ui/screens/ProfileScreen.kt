package com.roxi.player.ui.screens

import android.content.Intent
import android.net.Uri
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.FolderOpen
import androidx.compose.material.icons.rounded.HourglassEmpty
import androidx.compose.material.icons.rounded.Info
import androidx.compose.material.icons.rounded.LinkOff
import androidx.compose.material.icons.rounded.Refresh
import androidx.compose.material.icons.rounded.Timer
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.roxi.player.R
import com.roxi.player.data.formatListenTime
import com.roxi.player.ui.components.LocalBottomPadding
import com.roxi.player.ui.components.LocalVm
import com.roxi.player.ui.player.SleepTimerDialog
import com.roxi.player.ui.theme.Roxi

@Composable
fun ProfileScreen() {
    val vm = LocalVm.current
    val context = LocalContext.current
    val songs by vm.songs.collectAsStateWithLifecycle()
    val liked by vm.prefs.liked.collectAsStateWithLifecycle()
    val listenMs by vm.prefs.listenMs.collectAsStateWithLifecycle()
    val scanning by vm.scanning.collectAsStateWithLifecycle()
    val minDuration by vm.prefs.minDurationSec.collectAsStateWithLifecycle()
    val lyricsTree by vm.prefs.lyricsTree.collectAsStateWithLifecycle()
    val sleepEnd by vm.sleepTimerEnd.collectAsStateWithLifecycle()
    val bottom = LocalBottomPadding.current

    var durationDialog by remember { mutableStateOf(false) }
    var sleepDialog by remember { mutableStateOf(false) }
    var aboutDialog by remember { mutableStateOf(false) }

    val treePicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocumentTree()) { uri: Uri? ->
        if (uri != null) {
            try {
                context.contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
                vm.prefs.setLyricsTree(uri.toString())
                Toast.makeText(context, "Dossier des paroles enregistré", Toast.LENGTH_SHORT).show()
            } catch (e: Exception) {
                Toast.makeText(context, "Impossible d'utiliser ce dossier", Toast.LENGTH_SHORT).show()
            }
        }
    }

    Column(
        Modifier
            .fillMaxSize()
            .background(Roxi.Bg)
            .statusBarsPadding()
            .verticalScroll(rememberScrollState())
    ) {
        Column(
            Modifier
                .fillMaxWidth()
                .padding(top = 24.dp, bottom = 16.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
        ) {
            Image(
                painterResource(R.drawable.roxi_logo), null,
                modifier = Modifier
                    .size(96.dp)
                    .clip(CircleShape)
                    .background(Color.White),
                contentScale = ContentScale.Crop,
            )
            Spacer(Modifier.height(10.dp))
            Text("Roxi Player", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
        }

        Row(
            Modifier.padding(horizontal = 16.dp),
            horizontalArrangement = Arrangement.spacedBy(10.dp),
        ) {
            StatCard("${songs.size}", "Titres", Modifier.weight(1f))
            StatCard("${liked.size}", "Favoris", Modifier.weight(1f))
            StatCard(formatListenTime(listenMs), "Écoute", Modifier.weight(1f))
        }

        Spacer(Modifier.height(16.dp))
        SettingRow(
            Icons.Rounded.Refresh, "Rechercher la musique",
            if (scanning) "Recherche en cours…" else "${songs.size} titre(s) trouvé(s)",
        ) {
            vm.rescan()
            Toast.makeText(context, "Recherche lancée", Toast.LENGTH_SHORT).show()
        }
        SettingRow(
            Icons.Rounded.HourglassEmpty, "Durée minimale des fichiers",
            if (minDuration == 0) "Tous les fichiers" else "Ignorer les fichiers de moins de $minDuration s",
        ) { durationDialog = true }
        SettingRow(
            Icons.Rounded.FolderOpen, "Dossier des paroles (.lrc)",
            lyricsTree?.let { Uri.decode(it).substringAfterLast(':') }?.ifBlank { "Choisi" } ?: "Aucun dossier choisi",
        ) { treePicker.launch(null) }
        if (lyricsTree != null) {
            SettingRow(Icons.Rounded.LinkOff, "Oublier le dossier des paroles", "") {
                vm.prefs.setLyricsTree(null)
            }
        }
        SettingRow(Icons.Rounded.Timer, "Minuterie de sommeil", vm.sleepTimerLabel(sleepEnd)) { sleepDialog = true }
        SettingRow(Icons.Rounded.Info, "À propos", "Version 1.0") { aboutDialog = true }

        Spacer(Modifier.height(bottom + 16.dp))
    }

    if (durationDialog) {
        AlertDialog(
            onDismissRequest = { durationDialog = false },
            containerColor = Roxi.Surface,
            title = { Text("Durée minimale") },
            text = {
                Column {
                    listOf(0, 15, 30, 60).forEach { s ->
                        Text(
                            if (s == 0) "Tous les fichiers" else "$s secondes",
                            color = if (s == minDuration) Roxi.VioletSoft else Roxi.Text,
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(8.dp))
                                .clickable {
                                    vm.prefs.setMinDuration(s)
                                    durationDialog = false
                                }
                                .padding(vertical = 12.dp, horizontal = 8.dp),
                        )
                    }
                }
            },
            confirmButton = { TextButton(onClick = { durationDialog = false }) { Text("Fermer") } },
        )
    }
    if (sleepDialog) SleepTimerDialog { sleepDialog = false }
    if (aboutDialog) {
        AlertDialog(
            onDismissRequest = { aboutDialog = false },
            containerColor = Roxi.Surface,
            title = { Text("Roxi Player") },
            text = { Text("Lecteur de musique locale.\nVersion 1.0\nFonctionne sans Internet.") },
            confirmButton = { TextButton(onClick = { aboutDialog = false }) { Text("OK") } },
        )
    }
}

@Composable
private fun StatCard(value: String, label: String, modifier: Modifier) {
    Column(
        modifier
            .clip(RoundedCornerShape(16.dp))
            .background(Roxi.Surface)
            .padding(vertical = 14.dp, horizontal = 8.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Text(value, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
        Text(label, style = MaterialTheme.typography.bodySmall, color = Roxi.TextSub)
    }
}

@Composable
private fun SettingRow(icon: ImageVector, title: String, subtitle: String, onClick: () -> Unit) {
    Row(
        Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .padding(horizontal = 20.dp, vertical = 14.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Icon(icon, null, tint = Roxi.VioletSoft)
        Spacer(Modifier.width(16.dp))
        Column(Modifier.weight(1f)) {
            Text(title, style = MaterialTheme.typography.bodyLarge)
            if (subtitle.isNotEmpty()) {
                Text(
                    subtitle, style = MaterialTheme.typography.bodySmall, color = Roxi.TextSub,
                    maxLines = 1, overflow = TextOverflow.Ellipsis,
                )
            }
        }
    }
}
