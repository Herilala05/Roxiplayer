package com.roxi.player

import android.app.Application
import android.database.ContentObserver
import android.os.Handler
import android.os.Looper
import android.provider.MediaStore
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.roxi.player.data.Group
import com.roxi.player.data.LyricsRepository
import com.roxi.player.data.MusicRepository
import com.roxi.player.data.Prefs
import com.roxi.player.data.Song
import com.roxi.player.data.SortOrder
import com.roxi.player.data.formatTime
import com.roxi.player.data.sortSongs
import com.roxi.player.playback.PlayerController
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.drop
import kotlinx.coroutines.flow.flowOn
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import java.io.File

class MainViewModel(app: Application) : AndroidViewModel(app) {

    val prefs = Prefs(app)
    val lyrics = LyricsRepository(app)
    private val repo = MusicRepository(app)
    val player = PlayerController(app, viewModelScope)

    private val _songs = MutableStateFlow<List<Song>>(emptyList())
    val songs: StateFlow<List<Song>> = _songs.asStateFlow()

    private val _scanning = MutableStateFlow(false)
    val scanning: StateFlow<Boolean> = _scanning.asStateFlow()

    private val _hasScanned = MutableStateFlow(false)
    val hasScanned: StateFlow<Boolean> = _hasScanned.asStateFlow()

    private val _sleepTimerEnd = MutableStateFlow<Long?>(null)
    val sleepTimerEnd: StateFlow<Long?> = _sleepTimerEnd.asStateFlow()

    val songMap: StateFlow<Map<Long, Song>> = songs
        .map { list -> list.associateBy { it.id } }
        .flowOn(Dispatchers.Default)
        .stateIn(viewModelScope, SharingStarted.Eagerly, emptyMap())

    val currentSong: StateFlow<Song?> = combine(player.state, songMap) { st, map ->
        st.currentId?.let { map[it] }
    }.stateIn(viewModelScope, SharingStarted.Eagerly, null)

    val recentlyAdded: StateFlow<List<Song>> = songs
        .map { it.sortSongs(SortOrder.DATE_DESC) }
        .flowOn(Dispatchers.Default)
        .stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())

    val recentlyPlayed: StateFlow<List<Song>> = combine(prefs.recent, songMap) { ids, map ->
        ids.mapNotNull { map[it] }
    }.stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())

    val mostPlayed: StateFlow<List<Song>> = combine(prefs.playCounts, songMap) { counts, map ->
        counts.entries.sortedByDescending { it.value }.mapNotNull { map[it.key] }.take(30)
    }.stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())

    val likedSongs: StateFlow<List<Song>> = combine(prefs.liked, songMap) { ids, map ->
        ids.mapNotNull { map[it] }
    }.stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())

    val folders: StateFlow<List<Group>> = songs.map { list ->
        list.groupBy { it.folder }.map { (path, s) ->
            Group(path, File(path).name.ifEmpty { path }, path, s.sortSongs(SortOrder.AZ))
        }.sortedByDescending { it.songs.size }
    }.flowOn(Dispatchers.Default).stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())

    val artists: StateFlow<List<Group>> = songs.map { list ->
        list.groupBy { it.artist }.map { (name, s) ->
            Group(name, name, "${s.size} titre(s)", s.sortSongs(SortOrder.AZ))
        }.sortedBy { it.name.lowercase() }
    }.flowOn(Dispatchers.Default).stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())

    val albums: StateFlow<List<Group>> = songs.map { list ->
        list.groupBy { it.albumId }.map { (id, s) ->
            Group(id.toString(), s.first().album, s.first().artist, s)
        }.sortedBy { it.name.lowercase() }
    }.flowOn(Dispatchers.Default).stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())

    private var observerRegistered = false
    private var rescanJob: Job? = null
    private var sleepJob: Job? = null
    private var restored = false

    private val observer = object : ContentObserver(Handler(Looper.getMainLooper())) {
        override fun onChange(selfChange: Boolean) {
            rescanJob?.cancel()
            rescanJob = viewModelScope.launch {
                delay(2_000)
                rescan()
            }
        }
    }

    init {
        player.onConnected = { tryRestore() }
        player.onSongListened = { prefs.recordPlay(it) }
        player.onListenTime = { prefs.addListen(it) }
        player.onProgressSave = { id, pos ->
            prefs.lastSongId = id
            prefs.lastPosition = pos
        }
        player.connect()

        viewModelScope.launch {
            prefs.lyricsTree.collect { lyrics.setLyricsTree(it) }
        }
        viewModelScope.launch {
            prefs.minDurationSec.drop(1).collect { if (observerRegistered) rescan() }
        }
    }

    fun onPermissionGranted() {
        if (observerRegistered) return
        observerRegistered = true
        getApplication<Application>().contentResolver.registerContentObserver(
            MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, true, observer,
        )
        rescan()
    }

    fun rescan() {
        viewModelScope.launch {
            _scanning.value = true
            _songs.value = repo.scan(prefs.minDurationSec.value * 1000L)
            lyrics.clearCache()
            _scanning.value = false
            _hasScanned.value = true
            tryRestore()
        }
    }

    private fun tryRestore() {
        if (restored) return
        val list = recentlyAdded.value.ifEmpty { _songs.value.sortSongs(SortOrder.DATE_DESC) }
        if (list.isEmpty() || !player.state.value.connected) return
        restored = true
        val index = list.indexOfFirst { it.id == prefs.lastSongId }
        if (index >= 0) player.restore(list, index, prefs.lastPosition)
    }

    fun play(list: List<Song>, index: Int) = player.playSongs(list, index)

    fun shuffle(list: List<Song>) = player.playSongs(list, 0, shuffle = true)

    fun toggleLike(song: Song) = prefs.toggleLike(song.id)

    /** Minuterie de sommeil : null = désactiver. */
    fun setSleepTimer(minutes: Int?) {
        sleepJob?.cancel()
        if (minutes == null) {
            _sleepTimerEnd.value = null
            return
        }
        val end = System.currentTimeMillis() + minutes * 60_000L
        _sleepTimerEnd.value = end
        sleepJob = viewModelScope.launch {
            delay(minutes * 60_000L)
            player.pause()
            _sleepTimerEnd.value = null
        }
    }

    fun sleepTimerLabel(end: Long?): String =
        if (end == null) "Désactivée" else "Arrêt dans " + formatTime(end - System.currentTimeMillis())

    override fun onCleared() {
        if (observerRegistered) {
            getApplication<Application>().contentResolver.unregisterContentObserver(observer)
        }
        prefs.flushListen()
        player.release()
        super.onCleared()
    }
}
